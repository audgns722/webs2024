# webs2024
수업시간에 정리한 내용입니다. 
https://audgns722.github.io/webs2024/

## 자바스크립트
자바스크립트를 공부합니다. 
https://audgns722.github.io/webs2024/javascript/

## 레이아웃
여러가지 유형별 레이아웃을 공부합니다. 
https://audgns722.github.io/webs2024/layout/

## SQL
데이터베이스 MySQL을 공부합니다.
https://audgns722.github.io/webs2024/sql/

## SITE
웹표준을 준수한 사이트를 제작합니다.
https://audgns722.github.io/webs2024/site/